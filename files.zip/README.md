# MUI-OMNIVERSE

An open-source, modular, **offline-first** simulation laboratory in Python. One app, ten screens:
dashboard, embedded assistant, agent planner, living-world simulation, procedural map generator,
physics/particle lab, vision lab, music/MIDI lab, analytics, and workflow automation.

The core uses **only the Python standard library** (3.10+). No GPU, no paid API, no build step.

## Quick start

```bash
python run.py                  # then open http://127.0.0.1:8765
python -m unittest discover -s tests -v     # run the test suite (29 tests)
```

Optional extras (each unlocks one feature; see `requirements.txt`):

```bash
pip install pillow                    # Vision lab: image statistics
pip install transformers torch pillow # Vision lab: pretrained classifier (weights download once)
export ANTHROPIC_API_KEY=...          # or OPENAI_API_KEY=...  or run a local Ollama server
python run.py                         # assistant auto-selects a real LLM when available
```

Google Colab: `!python run.py &` then expose port 8765 (e.g. `google.colab.output.serve_kernel_port_as_iframe(8765)`).
The server binds to `127.0.0.1` by default and has **no authentication** — it is a single-user local tool.

## Layout

```
run.py                       launcher
mui_omniverse/
  server.py                  stdlib HTTP server + JSON API (thin layer)
  app.py                     OmniApp: owns state, registers agent tools, workflows, saves
  assistant.py               provider adapters (Anthropic, OpenAI-compatible, Ollama) + rule-based fallback
  agent.py                   tool registry, permission gate, planner, plan→execute→observe→revise executor
  sim.py                     living-world engine (agents, markets, events, replayable)
  mapgen.py                  procedural terrain / biomes / settlement sites
  physics.py                 particle system (grid broad-phase collisions)
  music.py                   composer + hand-written MIDI writer/parser + WAV preview synth
  vision.py                  optional pretrained classifier, honest basic-stats fallback
  analytics.py               summaries, run comparison, CSV/JSON export, SVG charts
  static/index.html          single-page UI (vanilla JS, canvas charts, no CDN)
data/workflows/*.json        sample automation workflows;  data/saves/ = saved worlds
exports/                     the only place tools may write (strict filename whitelist)
tests/test_core.py           29 automated tests
```

## Architecture in brief

* **UI ⟷ API ⟷ engines.** The browser only talks JSON to `server.py`; each engine is plain Python with no I/O.
* **Deterministic engines.** Every random draw comes from a seeded `random.Random`, so a world is
  `(seed, params, param-change log)`. Saving a world stores that spec and loading *replays* it.
* **No LLM in the simulation loop.** Agents use utility policies (price × skill, hunger overrides). An
  LLM could later act as a rare "advisor" through `World.set_params`; that hook exists but no such advisor is shipped.
* **Assistant honesty.** Every reply carries the backend that produced it. The rule-based fallback is
  keyword matching and is labelled "not a language model". Provider failures fall back visibly.
* **Agent safety.** Tools have permission levels (`safe`, `confirm`, `destructive`). The *registry itself*
  refuses non-safe calls without approval (HTTP 403), so it cannot be bypassed by skipping the UI step.
  There is deliberately **no tool that runs arbitrary or model-generated code**. File tools accept only
  `name.(csv|json|svg|mid|wav)` inside `exports/`. `http.fetch` needs approval and blocks private addresses.

## Honest feature notes

* Map "islands": with defaults you typically get one main landmass plus offshore islets; true archipelagos
  appear on some seeds and with higher sea level.
* The LLM-proposed planning path (`Planner._llm_plan`) exists and validates against the registry, but
  has **not been exercised against a live model** (no credentials were available). The template planner is what is tested.
* The Anthropic/OpenAI/Ollama adapters are implemented over plain HTTPS but **untested against live services**.
* The vision classifier path is untested here (no `transformers`/weights); only the fallback was run.
* The audio preview is a crude sine synth; the `.mid` file is the real output.
* Trust model: the `/api/agent/tool` endpoint accepts `approved:true` from the caller. The caller *is* the local
  user; do not expose the server to untrusted networks.

## Licence

Project code: MIT (`LICENSE`). Third-party notes and model-weight caveats: `THIRD_PARTY.md`.
